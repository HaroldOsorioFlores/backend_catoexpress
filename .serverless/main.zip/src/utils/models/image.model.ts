export type ImageProduct = {
  urlImage: string;
  public_id: string;
};
